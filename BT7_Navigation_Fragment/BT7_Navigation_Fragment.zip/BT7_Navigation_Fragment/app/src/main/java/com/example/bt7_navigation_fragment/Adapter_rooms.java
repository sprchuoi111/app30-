package com.example.bt7_navigation_fragment;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class Adapter_rooms extends RecyclerView.Adapter<myViewHolder> {
    private Context context;

    private List<Room> list_rooms;
    private SelectListener listener;
    private Adapter_rooms adapterRooms;

    public Adapter_rooms(Context context, List<Room> list_rooms ,SelectListener listener) {
        this.context = context;
        this.list_rooms = list_rooms;
        this.listener = listener;
    }
    // Inflater layout room to view
    @NonNull
    @Override
    public myViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view =LayoutInflater.from(context).inflate(R.layout.room_layout,parent,false);
        return new myViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull myViewHolder holder, int position) {
            holder.txt_name_room.setText(list_rooms.get(position).getName());
            holder.txt_des_room.setText(list_rooms.get(position).getDes());
            holder.img_room.setImageResource(list_rooms.get(position).getImg());
            final Room room  = list_rooms.get(position);
            if(room == null){
                return;
            }
            holder.card_room.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    listener.onItemClicked(room);
                }
            });
    }

    @Override
    public int getItemCount() {
        return list_rooms.size();
    }
}
