package com.example.bt7_navigation_fragment;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class DeviceFragment extends Fragment {
    ImageView img_room_device;

    TextView txt_name_room_device , txt_des_room_device;

    List<Device> list_devices;

    private RecyclerView recyclerView_devices;
    private MainActivity mMainActivity;
    private View mView;
    public DeviceFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // set data base of room
        mMainActivity = (MainActivity) getActivity();
        mView = inflater.inflate(R.layout.fragment_device, container, false);
        // set type of Recycler View
        GridLayoutManager gridLayoutManager = new GridLayoutManager(mMainActivity, 2 );
        // Casting
        recyclerView_devices = mView.findViewById(R.id.recyclerView_devices);
        recyclerView_devices.setLayoutManager(gridLayoutManager);
        recyclerView_devices.setHasFixedSize(true);

        // Inflate the layout for this fragment
        return mView;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        img_room_device = view.findViewById(R.id.img_room_device);
        txt_des_room_device = view.findViewById(R.id.txt_des_room_device);
        txt_name_room_device = view.findViewById(R.id.txt_name_room_device);
        Bundle bundleReceiver = getArguments();
        if(bundleReceiver != null){
            Room room = (Room) bundleReceiver.get("room");
            if (room != null){
                img_room_device.setImageResource(room.getImg());
                txt_des_room_device.setText(room.getDes());
                txt_name_room_device.setText(room.getName());
                // set adapter
                // create List device
                List<Device> deviceList = new ArrayList<>();
                deviceList = room.getList_device();
                if(deviceList != null){
                    Adapter_devices adapterDevices = new Adapter_devices(mMainActivity,deviceList , new SelectListener() {
                        @Override
                        public void onItemClicked(Room room) {

                        }

                        @Override
                        public void onItemClicked(Device device) {
                            Toast.makeText(mMainActivity , device.getName(), Toast.LENGTH_SHORT).show();
                        }
                    });
                    recyclerView_devices.setAdapter(adapterDevices);
                }
                else Toast.makeText(mMainActivity,"No data in array",Toast.LENGTH_SHORT).show();
            }
        }





    }
}