package com.example.bt7_navigation_fragment;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentStatePagerAdapter;
import androidx.fragment.app.FragmentTransaction;
import androidx.viewpager.widget.ViewPager;
import androidx.viewpager2.widget.ViewPager2;

import android.app.Activity;
import android.os.Bundle;
import android.telecom.Call;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.widget.Toolbar;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;
import com.google.android.material.navigation.NavigationView;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener{
    private BottomNavigationView bottom_navi;
    private ViewPager2 mViewPager;

    private DrawerLayout drawer_layout;
    private  Toolbar toolbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bottom_navi = findViewById(R.id.bottom_navi);
        mViewPager = findViewById(R.id.view_pager);
        drawer_layout = findViewById(R.id.drawer_layout);
        setUpViewPager();
        // set up tool bar
        toolbar  = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer_layout , toolbar ,
                R.string.navigation_drawer_open , R.string.navigation_drawer_close);
        drawer_layout.addDrawerListener(toggle);
        toggle.syncState();
        // Click event navigationView
        NavigationView navigation_view = findViewById(R.id.navigation_view);
        navigation_view.setNavigationItemSelectedListener(this);
        // Click event click on bottom navigation
        bottom_navi.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int id = item.getItemId();
                if(id == R.id.active_home){
                    mViewPager.setCurrentItem(0);
                } else if (id == R.id.active_favorite) {
                    mViewPager.setCurrentItem(1);
                } else if (id == R.id.active_author) {
                    mViewPager.setCurrentItem(2);
                }
                return true;
            }
        });

        // Slide pager event
        mViewPager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                super.onPageSelected(position);
                switch (position){
                    case 0:
                        navigation_view.getMenu().findItem(R.id.active_home).setChecked(true);
                        bottom_navi.getMenu().findItem(R.id.active_home).setChecked(true);
                        break;
                    case 1:
                        navigation_view.getMenu().findItem(R.id.active_favorite).setChecked(true);
                        bottom_navi.getMenu().findItem(R.id.active_favorite).setChecked(true);
                        break;
                    case 2:
                        navigation_view.getMenu().findItem(R.id.active_author).setChecked(true);
                        bottom_navi.getMenu().findItem(R.id.active_author).setChecked(true);
                        break;
                }
            }
        });




    }
    private void setUpViewPager(){
        ViewPagerAdapter mViewPagerAdapter = new ViewPagerAdapter(this);
        mViewPager.setAdapter(mViewPagerAdapter);
    }
    public void goto_Device_Fragment(Room room){
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        DeviceFragment deviceFragment = new DeviceFragment();

        // sent data to bundle;
        Bundle bundle = new Bundle();
        bundle.putSerializable("room" , room);

        // get bundle

        deviceFragment.setArguments(bundle);
        fragmentTransaction.replace(R.id.frame_list_device ,deviceFragment );
        mViewPager.setVisibility(View.GONE);
        fragmentTransaction.commit();
    }
    // Click event on NavigationView -- link to bottom Navigation
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if(id == R.id.active_home){
            mViewPager.setCurrentItem(0);
            bottom_navi.getMenu().findItem(R.id.active_home).setChecked(true);
        } else if (id == R.id.active_favorite) {
            mViewPager.setCurrentItem(1);
            bottom_navi.getMenu().findItem(R.id.active_favorite).setChecked(true);
        }
        else if (id == R.id.active_author) {
            mViewPager.setCurrentItem(2);
            bottom_navi.getMenu().findItem(R.id.active_author).setChecked(true);
        }

        drawer_layout.closeDrawer(GravityCompat.START);
        return true;
    }
    // push back -- not out app
    @Override
    public void onBackPressed() {
        if(drawer_layout.isDrawerOpen(GravityCompat.START)){
            drawer_layout.closeDrawer(GravityCompat.START);
        }
        else super.onBackPressed();
    }
}