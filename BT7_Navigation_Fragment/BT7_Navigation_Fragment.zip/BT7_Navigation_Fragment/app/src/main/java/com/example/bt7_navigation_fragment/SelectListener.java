package com.example.bt7_navigation_fragment;

public interface SelectListener {
    void onItemClicked(Room room);
    void onItemClicked(Device device);
}
